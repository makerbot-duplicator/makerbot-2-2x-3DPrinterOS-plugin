eeprom_map_name = 'eeprom_map_%s_%s.json'
default_version = '6.0'
default_software_variant = '0x00'
total_eeprom_size = 4000
