class UnknownVersionError(KeyError):
    """
    An UnkonwnVersionError is thrown when a version is passed
    into Uploader.py that is not found in a specific machine profile
    """
